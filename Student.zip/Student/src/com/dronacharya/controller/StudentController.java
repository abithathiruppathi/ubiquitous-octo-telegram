package com.dronacharya.controller;

import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ModelAttribute;
import com.dronacharya.model.Student;
import com.dronacharya.services.StudentServices;


@Controller
public class StudentController 
	{
	@Autowired	
	private StudentServices studentServices;
	
	public void setStudentServices(StudentServices stuServices)
		{
			this.studentServices=stuServices;
		}
	
	@RequestMapping("/stuForm")
	public String showForm(Model m)
		{
			m.addAttribute("stu", new Student());
			return "stuForm";
		}
	
	@RequestMapping(value="/save", method=RequestMethod.POST)
    public String save(@Valid @ModelAttribute("stu") Student student, BindingResult br)
    {
		System.out.println("In save; "+br);       
        if (br.hasErrors())
        {
        	System.out.println("In has errors");           
            return "stuForm";
        }
        else
        {
        	System.out.println("No errors"+student);           
            studentServices.save(student);
            return "/stuForm"; //redirect:
        }
    }
	
	@RequestMapping("/viewForm")
	
	public String viewStu(Model m)
	{
			List<Student> list=studentServices.getStudents();
			m.addAttribute("list", list);
			return "viewForm";
	}
	
	@RequestMapping(value="/deleteStu/{id}")
	
	public String delete(@PathVariable int id)
	{
		System.out.println("in delete id: "+id);
		studentServices.delete(id);
		return "redirect:/viewForm"; 
	}
}
