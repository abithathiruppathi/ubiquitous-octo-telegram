package com.dronacharya.services;

import com.dronacharya.model.Student;
import java.util.List;
import org.springframework.stereotype.Service;
import com.dronacharya.dao.StudentDao;
@Service
public class StudentServicesImpl implements StudentServices
{
	private StudentDao dao;
	public void setDao(StudentDao dao)
	{
		this.dao=dao;
	}
	
	@Override
	public int save(Student stu) 
	{
		return dao.save(stu);
	}
	
	@Override
	public List<Student> getStudents() 
	{
		return dao.getStudents();
	}
	@Override
	public int delete(int id) 
	{
		return dao.delete(id);
	}
}
