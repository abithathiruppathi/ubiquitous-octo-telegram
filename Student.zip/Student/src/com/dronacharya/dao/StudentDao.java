package com.dronacharya.dao;

import java.util.List;
import com.dronacharya.model.Student;

public interface StudentDao 
	{
		int save(Student stu);
		
		List<Student> getStudents();
		
		int delete(int id);
	}