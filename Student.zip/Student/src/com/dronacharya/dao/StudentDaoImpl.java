package com.dronacharya.dao;

import java.util.List;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import com.dronacharya.model.Student;
@Repository
public class StudentDaoImpl implements StudentDao 
	{
		private JdbcTemplate jdbcTemplate;
		public void setJdbcTemplate(JdbcTemplate jdbcTemplate)
		{
			this.jdbcTemplate=jdbcTemplate;
		}
		
		public int save(Student stu) 
		{
			System.out.println("In dao: "+stu);
			String sql="insert into stumvc(id, name, grade) values(?, ?, ?)";
			return jdbcTemplate.update(sql, new Object[] {stu.getId(), stu.getName(), 
			stu.getGrade()});
		}
		
		public List<Student> getStudents() 
		{
			String sql="select id, name, Grade from stumvc";
			return jdbcTemplate.query(sql, new StudentRowMapper());
		}
		
		public int delete(int id) 
		{
			String sql="delete from stumvc where id=?";
			return jdbcTemplate.update(sql, new Object[] {id});
		}
	}