package com.dronacharya.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import com.dronacharya.model.Student;
public class StudentRowMapper implements RowMapper<Student>
{
	public Student mapRow(ResultSet rs, int row) throws SQLException
	{
		Student stu=new Student();
		stu.setId(rs.getInt(1));
		stu.setName(rs.getString(2));
		stu.setGrade(rs.getDouble(3));
		return stu;
	}
}