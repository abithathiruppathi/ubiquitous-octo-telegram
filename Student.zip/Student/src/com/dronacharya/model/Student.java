package com.dronacharya.model;


import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class Student
{
	@NotEmpty(message = "Student id must not be empty")
	@Min(value = 1, message = "Student id starts from 1")
	@Max(value = 500, message = "Student id should be less than 500")
	private int id;
	
	@NotNull(message = "Student name must not be empty")
	@Size(min=3, max=15)
	private String name;
	
	@NotNull(message = "Enter your marks")
	private double grade;
	
	public Student() 
	{
		super();
		// TODO Auto-generated constructor stub
	}
	public Student(int id,String name,double grade) 
	{
		super();
		this.id=id;
		this.name=name;
		this.grade=grade;
		// TODO Auto-generated constructor stub
	}
	
	public int getId()
	{
		return id;
	}

	public void setId(int id) 
	{
		this.id = id;
	}

	public String getName() 
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public double getGrade()
	{
		return grade;
	}

	public void setGrade(double grade) 
	{
		this.grade = grade;
	}
	@Override
	public String toString()
	{
		return "Student [id=" + id + ", name=" + name + ", grade=" + grade + "]";
	}

}
