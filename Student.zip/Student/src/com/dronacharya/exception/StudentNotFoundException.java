package com.dronacharya.exception;

@SuppressWarnings("serial")
public class StudentNotFoundException extends Exception {
	
   public StudentNotFoundException(String msg)
	{
	     super(msg);
	}

}
